# Generation prompts

Built-in image_gen; five separate assets.

## 01

Use case: logo-brand.
Project: ICMS, a professional international academic congress management platform.
Create exactly ONE new icon, concept 01: CONFLUENCE / Research meets here.
MEANING FIRST: A congress exists because researchers with different perspectives come together around one shared question. The symbol must communicate distinct approaches finding a shared center. Do not merely decorate a letter.
Visual translation: THREE broad, fluid architectural ribbons approach a common center from directions 120 degrees apart. Each ribbon begins separately at the perimeter, curves gently inward, and ends around a small perfectly clear triangular central negative space. They interlock visually but never touch messily. The three parts create one compact rounded triangular silhouette, a quiet sense of gathering rather than spinning. This shared open center represents the question everyone contributes to. No arrowheads, no people pictograms, no literal roads.
Craft: bespoke Swiss modernist mark, precise equal-weight curves, optical balance, beautifully proportioned gaps; substantial solid forms legible at 16 pixels. Two ribbons in soft ivory #F1F3F0, one in muted glacial teal #7BD4C6.
Canvas: one square app tile, deep midnight #132632, controlled corner radius about 18%. Tile fills the square canvas completely edge-to-edge; the extreme rounded corners have genuine transparent alpha. The symbol takes about 62% of the tile width. No external surrounding margin or loose pixels.
Finish: pure flat vector-style logo, immaculate edges, smooth 2D solids, not a rendered object. No text, letters, wordmark, captions, mockup, diagram, tiny details, book, hat, atom, flower, decorative sparkles, arrows, gradients, glow, shadows, texture, beveling or 3D. It should feel like a confident enduring institutional technology identity. Square 1024px PNG.

## 02

Use case: logo-brand.
Make one sophisticated app icon for ICMS, a scholarly congress management platform. Concept 02: PAPER TO PODIUM.
MEANING: An unpublished research manuscript becomes a reviewed contribution and finally a presentation to the scholarly community. The system carries a paper through that complete journey. Encode that transformation in one continuous symbol, not a literal infographic.
Visual translation: ONE broad continuous geometric folded ribbon follows a short ascending zigzag. The lower-left section reads subtly as a stacked sheet edge, the central fold is the transition / review, and the upper-right section is a broad confident elevated plane like a presentation stage. Three large segments, two crisp folds, one uninterrupted journey. Silhouette roughly a compact diagonal S or three-dimensional stair translated into completely flat geometric planes. No arrowhead, no text, no literal book, no actual 3D. One inner cut creates a beautifully open angular negative space.
Palette: deep ink-indigo #222E57 full-bleed background; front ribbon planes warm ivory #F4F2EA, a single return plane cool cornflower #799BEF. Restrained high contrast.
Composition: square 1024px image, solid opaque background fills EVERY pixel to the image edges. NO transparency and NO rounded-square container, no outer border. The central symbol occupies 62% of the square with generous whitespace. Precisely optically balanced.
Art direction: premium editorial technology identity, confident architectural geometry, immaculately smooth flat vector shapes, lasting understated sophistication. Designed to read at 16px and 32px.
Avoid: image texture, gradients, grain, glow, lighting, shadows, metallic effects, embossing, bevels, photorealism, ornaments, tiny detail, captions, words, lettering, mockups, extra icons. Output only the finished graphic asset.

## 03

Use case: logo-brand.
Design ONE premium app icon for ICMS, an international academic congress and peer-review management system. Concept 03: PEER / Refined knowledge.
MEANING FIRST: Reliable academic knowledge becomes clearer when examined from more than one independent perspective. Two peers surround a contribution; a precise shared core emerges. Trust through review, not authority or security.
Visual translation: two opposing substantial geometric angle brackets, like a carefully designed < and >, together form an open diamond enclosure. Each bracket is made from a thick continuous bent band, about 90-degree angle, with subtly softened outer vertices and beautifully precise inner corners. The two bracket shapes DO NOT touch: deliberate equal gaps at the top and bottom. In the exact middle is one smaller solid square diamond, the refined contribution. The central diamond has generous negative space on all sides. A powerful compact symmetrical silhouette. This is an original optical mark, not typed keyboard characters.
Palette: chalk-white #F2F2EE full-bleed opaque square background; two brackets deep petroleum #173E48; the central diamond muted jewel teal #47AC9C. Sophisticated restrained three-color total palette.
Composition: icon asset alone; square 1024px image with background filling EVERY edge. No transparency, no enclosing card, no rounded-square outline, no external margin border. Central symbol about 63% square width. Excellent optical centering and balanced negative space.
Style: immaculate flat graphic / vector-like identity, broad confident forms, elegant institutional modernism. Distinctive at 16px, timeless at large size. Curated brand identity quality.
Avoid: shield, checkmark, medal, stars, microscope, literal people, books, graduation cap, arrows, text, words, title, typography, presentation board, fine lines, 3D, gradients, shadows, glow, bevels, surface texture, ornament.

## 04

Use case: logo-brand.
Create ONE elegant app-icon concept for ICMS, an INTERNATIONAL academic congress platform. Concept 04: OPEN EXCHANGE / Knowledge crosses borders.
MEANING FIRST: A discovery in one institution can become the beginning of another researcher's work anywhere in the world. Academic exchange connects different communities without closing the circle. Show two distinct domains sharing a continuous open passage.
Visual translation: a custom compact horizontal infinity-like symbol made from TWO thick open loops that cross beautifully at the center. Each loop has a deliberate clean outward-facing interruption, so the mark is an OPEN connection, not a closed chain. The crossing at the center is clear and graphic, created by a precise negative-space cut. One loop is warm ivory #F2F1E9, the other muted pale azure #82B8ED. Their two generous enclosed negative-space areas represent two communities; the middle crossing is the exchange. Do not use literal chain-link rectangles: use sculptural smooth asymmetric oval loops with a subtly rising motion. Wide ribbons, exact optical balance, refined controlled curves, horizontally compact 1.35:1 overall mark.
Background: solid deep marine blue #173749 covering every pixel of a square 1024px canvas. OPAQUE full-bleed background, no transparency, no rounded-square surrounding container, no border. Symbol occupies about 68% width and is optically centered.
Style: understated professional institutional identity, premium modern software brand, beautifully minimal flat vector-like design. Highly recognizable silhouette at favicon sizes. Two shapes, two foreground colors.
No globe lines, flags, map, people, book, letter, words, captions, extra circles, nucleus, arrowheads, gradients, light effects, shadows, glow, texture, 3D, plastic, metal, bevels or presentation board. Only the finished icon.

## 05

Use case: logo-brand.
Create ONE original sophisticated app icon for ICMS, a congress MANAGEMENT SYSTEM. Concept 05: ONE DESK / Organized as one.
MEANING FIRST: The platform brings four major responsibilities — paper submissions, participants, peer reviews, and congress schedules — into a single coherent workspace. Four independent modules share one operational center. The promise is clarity and coordination.
Visual translation: FOUR substantial modular shapes arranged as a compact perfectly balanced 2-by-2 square. Each module is a dark rounded square whose INNER corner has been cut away with a generous concave quarter-circle. Together those four cuts form ONE clean circular opening at the center. Place a small cobalt-blue filled circle at that shared center, with a generous light gap separating it from all four modules. The center is the unified control point, the four outer panels are the four work domains. Fine mathematical proportions, soft outer corners, crisp intentional negative space. Broad strong forms. Five shapes total. NOT a checkerboard, not four dots, not a flower, not an app launcher grid.
Palette: warm mineral-white #F0F0EB full-bleed opaque square background; modules dark graphite #252E37; center dot a restrained confident cobalt #4C73D8. No gradients.
Composition: one square 1024px graphic; background covers every pixel to the edges. NO transparency, no container card, no external borders. Central symbol fills about 61% of canvas width. Beautifully even margins.
Art direction: meticulous modern systems identity, professional and calm, high-end minimal editorial design, understated confident silhouette. Excellent small-size legibility. Absolutely flat vector-like clean shapes.
No text or words, no numbers, no annotations, no business clipart, no icons inside the four modules, no lines connecting parts, no extra marks, no 3D, no shadow, no glow, no texture, no bevel, no photographic effect, no mockup. Icon asset only.

## 01 background finishing

Use case: precise-object-edit. Technical finishing of this CONFLUENCE app icon.
Keep the three interlocking ivory and pale-teal ribbons and their shared central negative space EXACTLY as shown: same curves, positions, proportions, foreground colors and meaning.
CHANGE ONLY THE BACKGROUND: replace the whole background with one perfectly uniform, completely OPAQUE solid deep midnight color #132632, covering ALL pixels up to all four square edges. Fill the transparent corner areas and every dark or transparent patch with that same flat background color. Remove the enclosing rounded-square tile appearance. Full-bleed square background, 100% opaque, no transparency anywhere. Do not add texture, lighting, gradient, mottling, noise, shadows or halos. The background must be a mathematically flat solid color. Foreground is unchanged. Return one clean finished app icon.

